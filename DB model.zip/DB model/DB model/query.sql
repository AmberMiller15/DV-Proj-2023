SELECT 
	
	"Accidents"."CASENUM"

FROM 

	"Accidents"
	
INNER JOIN "Vehicles" 

	ON "Accidents"."CASENUM" = "Vehicles"."CASENUM";